MQTT delayed-feedback development replay

The results use the six uploaded Windows runs. All 16,800 feature windows and the five logged message skips are retained. The source contains 37,195 actual message attempts.

PRIMARY COMPARISON
16 scheduled individual-window reviews per run, with a simulated five-bin (one-second) response delay. Review source rotation and timing are fixed independently of labels, condition and predictions. Only a returned verified-normal window is admitted. A label never approves other windows from that account.

Totals across the two development seeds:
Policy | Authorized-change false alerts | Continuing violation probe alerts | New-source probe alerts
Frozen pooled | 400/1600 (25.00%) | 200/200 | 200/200
Unconditional pooled | 20/1600 (1.25%) | 2/200 | 2/200
Unconditional per-source | 4/1600 (0.25%) | 2/200 | 200/200
Reviewed pooled | 400/1600 (25.00%) | 200/200 | 200/200
Reviewed per-source | 117/1600 (7.31%) | 200/200 | 200/200

INTERPRETATION
Reviewed per-source calibration preserves alerts on the tested compromised-source and new-source probes, with slower adaptation to legitimate change than unconditional updating. Zero unauthorized admissions under simulated correct feedback is a property of the admission rule and oracle assumption.
The larger B64 budget is a finite-sample control: pooled calibration needs ten high-count admissions to move its threshold, while each source cutoff is its maximum. With B64, pooling verified normal drift can hide a new source violation even without malicious admissions.
These are scheduled-review baselines on two paired development seeds and emulated accounts. The windows are dependent. The replay does not establish a new defense, a formal 1% false-alert guarantee, real human review speed, or general attack performance. Review errors and changing authorization after an earlier approval remain untested.

FILES
key_results.csv contains the compact primary comparison. reports/summary.csv contains all five fixed settings and the original blind controls. reports/decisions.csv records every evaluated decision. reports/query_feedback_audit.csv separates request, availability, return and application times. reports/policy_report.json records costs, threshold changes, state hashes and retained contamination. reports/analysis_protocol.json records the settings and source hashes.

REPRODUCING
Copy code/replay_mqtt_feedback.py to the project code folder. It uses only the Python standard library and makes no network connections. From the project folder run:
.\.venv\Scripts\python.exe .\code\replay_mqtt_feedback.py
Its default input is the latest dated batch under results/mqtt_adaptation, with no fallback from a failed latest batch. Alternatively add --input followed by the original reports ZIP or exact batch folder. New results go under results/mqtt_feedback.

SOURCE
mqtt_adaptation_reports.zip
SHA256: e4743a60960aff083491abd9d9d3b5457851cdb2e2404c4405f2e01b87139653

RELATED WORK
Budgeted reference-data cleaning already appears in Bashari, Sesia and Romano, Robust Conformal Outlier Detection under Contaminated Reference Data: https://arxiv.org/abs/2502.04807 .
Feedback reliability is studied by Wang, Zecchin and Simeone, Online Conformal Prediction with Corrupted Feedback: https://arxiv.org/abs/2605.20515 . This package does not implement or inherit guarantees from either method.
