#!/usr/bin/env python3
"""Offline delayed-feedback baselines on the existing MQTT development batch.

    python code/replay_mqtt_feedback.py
Or: python code/replay_mqtt_feedback.py --input PATH_TO_MQTT_ADAPTATION_REPORTS_ZIP
Standard library only. No broker, recollection, ML environment or old Python files.
"""
import argparse
import csv
import hashlib
import io
import json
import math
import re
import sys
import uuid
import zipfile
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
from itertools import groupby
from pathlib import Path, PurePosixPath

VERSION, ALPHA, WIDTH = "1.0", .01, 200_000_000
SOURCE_SHA = "2c5c5c584ed274ca8fa25b2ca829ae18868ba5b2a4d6fbe90a29a40812532b40"
CORE_SHA = "40984ae9dec1872e633738cfbcdd478b85de6fb34052ac4a9b2732972dc2f918"
USERS = [f"sensor{i:02d}" for i in range(1, 9)]
CASES = [(201, "stationary"), (201, "authorized_shift"), (201, "compromised_shift"),
         (202, "compromised_shift"), (202, "authorized_shift"), (202, "stationary")]
PHASES = [("warmup", 0, 10), ("train", 10, 60), ("calibration", 60, 185),
          ("baseline_eval", 185, 200), ("adaptation", 200, 300), ("probe_eval", 300, 350)]
CONFIGS = [(16, 5, "primary"), (0, 5, "sensitivity"), (64, 5, "sensitivity"),
           (16, 0, "sensitivity"), (16, 25, "sensitivity")]
POLICIES = ["reviewed_pooled", "reviewed_source"]
GROUPS = {"overall": USERS, "first_two": USERS[:2], "middle_four": USERS[2:6], "probe_last_two": USERS[6:]}
TOP = ["experiment_protocol.json", "batch_summary.json", "policy_report.json", "policy_decisions.csv",
       "policy_trace.csv", "admission_audit.csv", "buffer_snapshot_audit.csv", "alarm_summary.csv"]
RAW = ["events.jsonl", "ground_truth.jsonl", "protocol.json", "run_summary.json", "windows_features.csv",
       "windows_metadata.csv", "windows_authorization.csv"]
SAFE_FIELDS = {"row_id", "source", "bin_index", "phase", "score"}
LIMITS = ["Known development data; these are feedback baselines, not a novel defense or blinded final evaluation.",
          "Six runs contain only two paired seeds and eight emulated accounts on one host. No new traffic is collected.",
          "All original rows, five skipped message slots and timing variations remain; no clean-run filtering or retry.",
          "Perfect trusted review of selected individual windows is simulated. Review errors, real human cost and measured review latency are not established.",
          "Labels become available only for requested windows after a fixed simulated bin delay; all other truth joins are reporting only.",
          "A verified-normal window can enter the calibration FIFO once; it never whitelists its source or authorizes unreviewed future admissions.",
          "Review slots and account rotation are fixed independently of condition, oracle labels, scores and model predictions.",
          "All eight current rows score before queries, replies or updates, so even zero-delay feedback first affects a later bin.",
          "Probe replies are logged but never applied. No query is issued during the probe.",
          "125-row source calibration uses its maximum; pooled1000 uses rank991. Reviewed-normal drift can move a global cutoff across sources without any poisoning.",
          "B16 supplies only four shifted-source reviews in ideal paired traffic; fewer than the ten high entries needed to move the pooled cutoff. B64 is a fixed capacity control.",
          "Dependent windows do not support an IID or distribution-free 1% guarantee. No configuration is selected as best."]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def state_sha(state):
    return sha(canonical(state).encode())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")


def write_csv(path, rows):
    require(bool(rows), "Empty output table.")
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


class Source:
    def __init__(self, requested):
        self.requested, self.path = str(requested), Path(requested).resolve()
        self.selection, self.cache, self.archive = "explicit ZIP or batch", {}, None
        if self.path.is_dir() and not (self.path / "batch_summary.json").is_file():
            candidates = sorted(path for path in self.path.iterdir() if path.is_dir()
                                and re.fullmatch(r"\d{8}T\d{6}Z_[0-9a-f]{12}", path.name))
            require(bool(candidates), "No dated batch found; supply --input with the ZIP or exact batch folder.")
            self.path, self.selection = candidates[-1], "latest dated batch without pass/fail filtering"
        self.allowed = set(TOP) | {f"run_{i}_seed_{seed}_{arm}/{name}" for i, (seed, arm) in enumerate(CASES, 1) for name in RAW}
        require(self.path.exists(), f"Input not found: {self.path}")
        if self.path.is_file():
            require(zipfile.is_zipfile(self.path), "File input must be the adaptation reports ZIP.")
            self.archive = zipfile.ZipFile(self.path)
            names = self.archive.namelist()
            require(len(names) == len(set(names)) == 50 and set(names) == self.allowed, "ZIP must have exactly the original50 allowlisted report files.")
            for info in self.archive.infolist():
                p = PurePosixPath(info.filename)
                require(not p.is_absolute() and ".." not in p.parts and "\\" not in info.filename
                        and (info.external_attr >> 16 & 0o170000) != 0o120000, "Unsafe archive member.")
            require(sum(info.file_size for info in self.archive.infolist()) < 1_000_000_000, "Unexpected archive size.")
        print(f"Selected input: {self.path}\nSelection: {self.selection}", flush=True)

    def read(self, name):
        require(name in self.allowed, "Refusing an unlisted source file.")
        if name not in self.cache:
            path = (self.path / name).resolve()
            require(self.archive is not None or self.path in path.parents, "Source path escapes batch.")
            self.cache[name] = self.archive.read(name) if self.archive else path.read_bytes()
        return self.cache[name]

    def json(self, name):
        return json.loads(self.read(name).decode("utf-8-sig"))

    def table(self, name):
        reader = csv.DictReader(io.StringIO(self.read(name).decode("utf-8-sig"), newline=""))
        require(reader.fieldnames and len(reader.fieldnames) == len(set(reader.fieldnames)), f"Invalid CSV header: {name}")
        rows = list(reader)
        require(all(None not in row and None not in row.values() for row in rows), f"Malformed CSV: {name}")
        return rows


def validate_source(source):
    batch, experiment = source.json("batch_summary.json"), source.json("experiment_protocol.json")
    require(batch["program_version"] == experiment["program_version"] == "2.0"
            and batch["script_sha256"] == experiment["script_sha256"] == SOURCE_SHA
            and batch["core_sha256"] == experiment["core_sha256"] == CORE_SHA, "Unsupported original collection code/version.")
    require(batch["status"] == "passed" and not batch["errors"] and batch["quick_engineering_only"] is False
            and experiment["quick_engineering_only"] is False and len(batch["runs"]) == 6
            and batch["planned_order"] == experiment["planned_order"] == [list(case) for case in CASES], "Require the full passed nonquick six-run batch.")
    require(set(batch["report_sha256"]) == set(TOP) - {"batch_summary.json"}, "Unexpected top-level hash manifest.")
    for name, expected in batch["report_sha256"].items():
        require(sha(source.read(name)) == expected, f"Source report hash mismatch: {name}")
    old_report = source.json("policy_report.json")
    require(old_report["analysis_status"] == "completed" and not old_report["errors"] and len(old_report["runs_and_policies"]) == 18,
            "Original blind-policy analysis is incomplete.")
    runs, row_lookup, truth, clocks = [], {}, {}, {}
    for index, (seed, arm) in enumerate(CASES, 1):
        prefix = f"run_{index}_seed_{seed}_{arm}"
        summary, protocol = source.json(prefix + "/run_summary.json"), source.json(prefix + "/protocol.json")
        require(summary == batch["runs"][index - 1] and summary["program_version"] == protocol["program_version"] == "2.0"
                and summary["status"] == "passed" and summary["quick_engineering_only"] is False
                and summary["schedule_quality_evaluable"] and summary["schedule_quality_passed"]
                and summary["maximum_source_skipped_fraction"] <= .01 and summary["schedule_skipped_fraction"] <= .01,
                "Run transport/quality/summary failed.")
        require(not summary["issues"] and not summary["cleanup_errors"] and summary["original_error"] is None
                and summary["credential_file_removed"] is True, "Unresolved collection error.")
        run_id, epoch = summary["run_id"], summary["measurement_start_monotonic_ns"]
        require((summary["seed"], summary["condition"]) == (seed, arm)
                and (protocol["seed"], protocol["condition"], protocol["run_id"]) == (seed, arm, run_id)
                and protocol["publishers"] == USERS and protocol["window_width_ns"] == WIDTH
                and protocol["phases"] == [{"name": name, "start_ns": start * WIDTH, "end_ns": end * WIDTH} for name, start, end in PHASES]
                and summary["observation_stop_monotonic_ns"] >= epoch + 350 * WIDTH, "Run identity/clock/protocol mismatch.")
        require(set(summary["file_sha256"]) == set(RAW) - {"run_summary.json"}, "Unexpected raw hash manifest.")
        for name, expected in summary["file_sha256"].items():
            require(sha(source.read(prefix + "/" + name)) == expected, f"Raw source hash mismatch: {prefix}/{name}")
        fs, ms, au = [source.table(prefix + "/" + name) for name in RAW[4:]]
        require(len(fs) == len(ms) == len(au) == summary["window_rows"] == 2800, "Incomplete feature/authorization join.")
        require(set(fs[0]) == {"row_id", "message_count", "mean_payload_bytes", "std_payload_bytes"}, "Unexpected feature schema.")
        rows = []
        for pos, (f, m, a) in enumerate(zip(fs, ms, au)):
            b, user = pos // 8, USERS[pos % 8]
            phase = next(name for name, start, end in PHASES if start <= b < end)
            rid = f"{run_id}:{user}:{b:05d}"
            require(f["row_id"] == m["row_id"] == a["row_id"] == rid and rid not in row_lookup
                    and m["run_id"] == a["run_id"] == run_id and m["seed"] == a["seed"] == str(seed)
                    and m["condition"] == a["condition"] == arm and m["authenticated_username"] == a["authenticated_username"] == user
                    and m["bin_index"] == a["bin_index"] == str(b) and m["nominal_phase"] == a["nominal_phase"] == phase
                    and m["complete_bin"] == a["complete_bin"] == "True"
                    and int(m["window_start_monotonic_ns"]) == epoch + b * WIDTH
                    and int(m["window_end_monotonic_ns"]) == epoch + (b + 1) * WIDTH, "Row identity/join/chronology mismatch.")
            values = [float(f[key]) for key in ["message_count", "mean_payload_bytes", "std_payload_bytes"]]
            normal, unauthorized = int(a["normal_message_count"]), int(a["unauthorized_message_count"])
            label = ("mixed_authorization_messages" if normal and unauthorized else "unauthorized_policy_violation" if unauthorized
                     else "normal_authorized_workload" if normal else "no_observed_messages")
            require(all(math.isfinite(value) and value >= 0 for value in values) and values[0].is_integer()
                    and normal >= 0 and unauthorized >= 0 and normal + unauthorized == values[0]
                    and m["oracle_label"] == a["oracle_label"] == label, "Feature or authorization count/label mismatch.")
            if phase == "calibration":
                require(label == "normal_authorized_workload" and unauthorized == 0, "Trusted calibration is not clean.")
            row = {"row_id": rid, "source": user, "bin_index": b, "phase": phase, "score": int(values[0])}
            rows.append(row)
            row_lookup[rid], truth[rid], clocks[rid] = row, a, epoch
        runs.append({"run_id": run_id, "seed": seed, "condition": arm, "rows": rows, "collection_summary": summary})
    # Read all50 named files, but no credentials or unlisted archive members.
    for name in sorted(source.allowed):
        source.read(name)
    old_decisions, old_alarms = source.table("policy_decisions.csv"), source.table("alarm_summary.csv")
    seen = set()
    for d in old_decisions:
        row = row_lookup[d["row_id"]]
        key = (d["run_id"], d["policy"], d["row_id"])
        require(key not in seen and d["source"] == row["source"] and d["phase"] == row["phase"]
                and int(d["bin_index"]) == row["bin_index"] and float(d["score"]) == row["score"]
                and d["flagged"] == str(d["threshold"] != "" and float(d["score"]) > float(d["threshold"])), "Original decision mismatch.")
        seen.add(key)
    require(len(old_decisions) == 23760, "Incomplete original reference decisions.")
    return runs, row_lookup, truth, clocks, old_decisions, old_alarms, old_report


def review_plan(seed, budget):
    require(0 <= budget <= 100, "Review budget must be in0..100.")
    order = sorted(USERS, key=lambda user: hashlib.sha256(f"review-plan:{seed}:{user}".encode()).hexdigest())
    return [{"ordinal": j, "offset": j * 100 // budget, "source": order[j % 8]} for j in range(budget)]


class DelayedFeedbackProvider:
    """Oracle boundary: only requested and ready row verdicts can be released."""
    def __init__(self, verified_normal_by_row):
        require(isinstance(verified_normal_by_row, dict)
                and all(isinstance(value, bool) for value in verified_normal_by_row.values()),
                "Feedback verdicts must be explicit Boolean values.")
        self._answers, self._pending, self._requested = dict(verified_normal_by_row), [], set()

    def request(self, query_id, row_id, request_bin, ready_bin):
        require(row_id in self._answers and query_id not in self._requested and ready_bin >= request_bin, "Invalid/duplicate review request.")
        self._requested.add(query_id)
        self._pending.append({"query_id": query_id, "row_id": row_id, "request_bin": request_bin, "ready_bin": ready_bin})

    def release(self, bin_index):
        due = [item for item in self._pending if item["ready_bin"] <= bin_index]
        self._pending = [item for item in self._pending if item["ready_bin"] > bin_index]
        return [{**item, "verified_normal": bool(self._answers[item["row_id"]])} for item in due]


def quantile(entries):
    values = sorted(row["score"] for row in entries)
    rank = math.ceil((len(values) + 1) * (1 - ALPHA))
    return (values[rank - 1] if rank <= len(values) else None), rank


def replay_feedback(rows, seed, budget, delay, policy, provider):
    """Pure causal baseline: five row fields plus a request/release provider API."""
    require(policy in POLICIES and delay >= 0 and rows and all(set(row) == SAFE_FIELDS for row in rows), "Invalid policy/input allowlist.")
    require(all(row["source"] in USERS and math.isfinite(row["score"]) and row["score"] >= 0 for row in rows), "Invalid count/source.")
    groups = [(b, list(group)) for b, group in groupby(rows, key=lambda row: row["bin_index"])]
    require([b for b, group in groups] == list(range(350)) and len({row["row_id"] for row in rows}) == len(rows)
            and all([row["source"] for row in group] == USERS and all(row["phase"] == next(name for name, start, end in PHASES if start <= b < end) for row in group)
                    for b, group in groups), "Expected full chronological eight-source bins.")
    entry = lambda row: {key: row[key] for key in ["row_id", "source", "score"]}
    lookup = {row["row_id"]: row for row in rows}
    calibration = [entry(row) for row in rows if row["phase"] == "calibration"]
    buffers = ({user: deque([row for row in calibration if row["source"] == user], maxlen=125) for user in USERS}
               if policy == "reviewed_source" else {"pooled": deque(calibration, maxlen=1000)})
    require(len(calibration) == 1000 and all(len(values) == (125 if policy == "reviewed_source" else 1000) for values in buffers.values()), "Wrong trusted calibration size.")
    state = lambda: {key: list(values) for key, values in buffers.items()}
    cutoffs = lambda: {key: quantile(values)[0] for key, values in buffers.items()}
    initial = {key: {"rows": len(values), "rank_one_based": quantile(values)[1], "threshold": quantile(values)[0],
                       "score_distribution": dict(Counter(row["score"] for row in values))} for key, values in buffers.items()}
    plan = {200 + item["offset"]: item for item in review_plan(seed, budget)}
    decisions, queries, snapshots, moves = [], {}, [], []
    def snapshot(stage, b):
        current = state()
        snapshots.append({"stage": stage, "bin_index": b, "thresholds": cutoffs(), "state_sha256": state_sha(current), "buffers": current})
    for b, group in groups[185:]:
        phase, before = group[0]["phase"], cutoffs()
        if b == 200:
            snapshot("adaptation_start", b)
        # No query, answer or update is processed until all current rows score.
        for row in group:
            threshold = before[row["source"] if policy == "reviewed_source" else "pooled"]
            decisions.append({**row, "threshold": threshold, "threshold_is_infinite": threshold is None,
                              "flagged": threshold is not None and row["score"] > threshold})
        if b in plan:
            item = plan[b]
            row = next(row for row in group if row["source"] == item["source"])
            query_id = f"review-{item['ordinal']:03d}:{row['row_id']}"
            provider.request(query_id, row["row_id"], b, b + delay)
            queries[query_id] = {"query_id": query_id, "row_id": row["row_id"], "source": row["source"],
                "request_bin": b, "ready_bin": b + delay, "return_bin": None, "apply_bin": None,
                "feedback_returned": False, "verified_normal": None, "applied_normal": False, "status": "pending_after_horizon"}
        for reply in provider.release(b):
            query = queries[reply["query_id"]]
            require(reply["row_id"] == query["row_id"] and reply["request_bin"] == query["request_bin"]
                    and reply["ready_bin"] == query["ready_bin"] and b >= reply["ready_bin"]
                    and isinstance(reply["verified_normal"], bool) and not query["feedback_returned"],
                    "Provider returned an early, unrequested, changed or duplicate answer.")
            query.update({"return_bin": b, "feedback_returned": True, "verified_normal": reply["verified_normal"]})
            if phase != "adaptation":
                query["status"] = "late_return_frozen_phase"
            elif not reply["verified_normal"]:
                query["status"] = "rejected_not_verified_normal"
            else:
                reviewed = lookup[reply["row_id"]]
                buffers[reviewed["source"] if policy == "reviewed_source" else "pooled"].append(entry(reviewed))
                query.update({"apply_bin": b, "applied_normal": True, "status": "applied_verified_normal"})
        after = cutoffs()
        if after != before:
            moves.append({"bin_index": b, "thresholds_before": before, "thresholds_after": after,
                          "applied_query_ids": [q["query_id"] for q in queries.values() if q["apply_bin"] == b]})
        if b == 299:
            snapshot("adaptation_end", b)
        if b == 349:
            snapshot("probe_end", b)
    require(snapshots[1]["state_sha256"] == snapshots[2]["state_sha256"], "Probe changed calibration state.")
    audit = list(queries.values())
    require(len(audit) == budget, "Fixed review budget was not issued exactly.")
    counts = {"requested": len(audit), "returned": sum(q["feedback_returned"] for q in audit),
        "applied_normal": sum(q["applied_normal"] for q in audit), "rejected_during_adaptation": sum(q["status"] == "rejected_not_verified_normal" for q in audit),
        "late_returns_not_applied": sum(q["status"] == "late_return_frozen_phase" for q in audit),
        "late_verified_normal_not_applied": sum(q["status"] == "late_return_frozen_phase" and q["verified_normal"] is True for q in audit),
        "pending_after_horizon": sum(not q["feedback_returned"] for q in audit)}
    return {"decisions": decisions, "queries": audit, "initial_calibration": initial, "snapshots": snapshots,
            "threshold_moves": moves, "feedback_counts": counts, "review_plan": list(plan.values())}


def summarize(decisions, truth, common):
    result = []
    for phase in ["baseline_eval", "adaptation", "probe_eval"]:
        for group, users in GROUPS.items():
            selected = [row for row in decisions if row["phase"] == phase and row["source"] in users]
            for label in ["all_windows", *sorted({truth[row["row_id"]]["oracle_label"] for row in selected})]:
                subset = selected if label == "all_windows" else [row for row in selected if truth[row["row_id"]]["oracle_label"] == label]
                flagged = sum(row["flagged"] for row in subset)
                result.append({**common, "phase": phase, "source_group": group, "observed_authorization": label,
                               "rows": len(subset), "flagged": flagged, "flag_fraction": flagged / len(subset)})
    return result


def audit_snapshots(snapshots, truth):
    result = []
    for snapshot in snapshots:
        audited = {}
        for key, entries in snapshot["buffers"].items():
            contaminated = sum(int(truth[row["row_id"]]["unauthorized_message_count"]) > 0 for row in entries)
            audited[key] = {"rows": len(entries), "entries_sha256": state_sha(entries), "score_distribution": dict(Counter(row["score"] for row in entries)),
                "source_composition": dict(Counter(row["source"] for row in entries)), "unauthorized_windows": contaminated,
                "unauthorized_window_fraction": contaminated / len(entries),
                "unauthorized_messages": sum(int(truth[row["row_id"]]["unauthorized_message_count"]) for row in entries),
                "normal_messages": sum(int(truth[row["row_id"]]["normal_message_count"]) for row in entries)}
        result.append({**{key: value for key, value in snapshot.items() if key != "buffers"}, "buffer_audit": audited})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default="results/mqtt_adaptation")
    parser.add_argument("--output", default="results/mqtt_feedback")
    args = parser.parse_args()
    source = Source(args.input)
    try:
        runs, row_lookup, truth, clocks, old_decisions, old_alarms, old_report = validate_source(source)
    finally:
        if source.archive:
            source.archive.close()
    output_root = Path(args.output).resolve()
    require(not (source.path.is_dir() and (output_root == source.path or source.path in output_root.parents)), "Keep output outside source batch.")
    output = output_root / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ_") + uuid.uuid4().hex[:12])
    output.mkdir(parents=True, exist_ok=False)
    protocol = {"program_version": VERSION, "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "Offline fixed-budget delayed-feedback baseline on preserved known development observations.",
        "input_requested": Path(source.requested).name, "input_selected": source.path.name, "input_selection_rule": source.selection,
        "source_sha256": {name: sha(raw) for name, raw in sorted(source.cache.items())},
        "source_program_sha256": SOURCE_SHA, "core_sha256": CORE_SHA, "script_sha256": sha(Path(__file__).read_bytes()),
        "configurations": [{"budget": b, "delay_bins": d, "role": role} for b, d, role in CONFIGS], "policies": POLICIES,
        "review_schedule": "Slots floor(j*100/B), j=0..B-1, on the100 adaptation bins. Source order sorted by SHA256('review-plan:{seed}:{username}'), repeated round-robin. No scores, labels, roles or condition used.",
        "within_bin_order": "Score all8 rows; issue fixed query; release answers whose ready_bin<=current bin; apply only verified-normal individual windows while still in adaptation. D0 affects next bin at earliest.",
        "feedback": "Perfect simulated trusted individual-window review; provider exposes only requested ready binary normal verdicts. Pending probe answers are logged, never applied.",
        "replay_time": "Bin clocks are simulated response availability and application times on the recorded monotonic timeline, not measured human response latency.",
        "calibration": {"pooled_rows": 1000, "source_rows": 125, "alpha": ALPHA, "rank_rule": "ceil((n+1)*.99); strict score>threshold; rank>n becomes infinity/JSON null"},
        "policy_input_allowlist": sorted(SAFE_FIELDS), "blind_references": "Original three no-review policies copied from validated source decisions, without network replay.",
        "limits": LIMITS, "environment": {"python": sys.version}}
    write_json(output / "analysis_protocol.json", protocol)  # Frozen before replay.
    summaries, decisions, feedback_audit, records = [], [], [], []
    for run in runs:
        for budget, delay, role in CONFIGS:
            for policy in POLICIES:
                common = {"run_id": run["run_id"], "seed": run["seed"], "condition": run["condition"],
                    "configuration": f"B{budget}_D{delay}", "role": role, "budget": budget, "delay_bins": delay, "policy": policy}
                verified = {row["row_id"]: truth[row["row_id"]]["oracle_label"] == "normal_authorized_workload" for row in run["rows"]}
                result = replay_feedback(run["rows"], run["seed"], budget, delay, policy, DelayedFeedbackProvider(verified))
                summaries.extend(summarize(result["decisions"], truth, common))
                decisions.extend({**common, **row} for row in result["decisions"])
                for query in result["queries"]:
                    actual, epoch = truth[query["row_id"]], clocks[query["row_id"]]
                    feedback_audit.append({**common, **query,
                        "request_window_end_monotonic_ns": epoch + (query["request_bin"] + 1) * WIDTH,
                        "response_ready_monotonic_ns": epoch + (query["ready_bin"] + 1) * WIDTH,
                        "response_returned_monotonic_ns": None if query["return_bin"] is None else epoch + (query["return_bin"] + 1) * WIDTH,
                        "application_monotonic_ns": None if query["apply_bin"] is None else epoch + (query["apply_bin"] + 1) * WIDTH,
                        "audit_oracle_label": actual["oracle_label"], "audit_normal_message_count": int(actual["normal_message_count"]),
                        "audit_unauthorized_message_count": int(actual["unauthorized_message_count"])})
                records.append({**common, "initial_calibration": result["initial_calibration"], "feedback_counts": result["feedback_counts"],
                    "review_plan": result["review_plan"], "threshold_moves": result["threshold_moves"], "snapshots": audit_snapshots(result["snapshots"], truth)})
        print(f"Replayed all fixed settings: seed {run['seed']} {run['condition']}", flush=True)
    reference_common = lambda row: {"run_id": row["run_id"], "seed": int(row["seed"]), "condition": row["condition"],
        "configuration": "blind_reference", "role": "blind_reference", "budget": 0, "delay_bins": None, "policy": row["policy"]}
    for row in old_decisions:
        decisions.append({**reference_common(row), **{key: row[key] for key in ["row_id", "source", "bin_index", "phase"]},
            "score": int(row["score"]), "threshold": None if row["threshold"] == "" else float(row["threshold"]),
            "threshold_is_infinite": row["threshold_is_infinite"] == "True", "flagged": row["flagged"] == "True"})
    for row in old_alarms:
        summaries.append({**reference_common(row), **{key: row[key] for key in ["phase", "source_group", "observed_authorization"]},
                          "rows": int(row["rows"]), "flagged": int(row["flagged"]), "flag_fraction": float(row["flag_fraction"])})
    write_csv(output / "summary.csv", summaries)
    write_csv(output / "decisions.csv", decisions)
    write_csv(output / "query_feedback_audit.csv", feedback_audit)
    write_json(output / "policy_report.json", {"program_version": VERSION, "status": "completed", "runs_and_policies": records,
        "original_blind_policy_records": old_report["runs_and_policies"], "summary_rows": len(summaries), "decision_rows": len(decisions),
        "query_audit_rows": len(feedback_audit), "limits": LIMITS,
        "file_sha256": {name: sha((output / name).read_bytes()) for name in ["analysis_protocol.json", "summary.csv", "decisions.csv", "query_feedback_audit.csv"]}})
    names = ["analysis_protocol.json", "summary.csv", "decisions.csv", "query_feedback_audit.csv", "policy_report.json"]
    with zipfile.ZipFile(output / "feedback_replay_reports.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for name in names:
            archive.write(output / name, arcname=name)
    print("Offline feedback baseline complete. All original observations preserved; no new traffic or novel defense claim.")
    print("Reports ZIP:", output / "feedback_replay_reports.zip")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
        raise SystemExit(f"Feedback replay stopped: {type(error).__name__}: {error}")
